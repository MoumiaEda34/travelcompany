import React, { useEffect, useState } from 'react';
import { useLocation, useNavigate } from 'react-router-dom';
import { Card, Container, Button } from 'react-bootstrap';
import './BookingConfirmation.css';

const BookingConfirmation = () => {
  const location = useLocation();
  const navigate = useNavigate(); // Initialize useNavigate for navigation
  const { accommodation, userName } = location.state || {}; // Get accommodation and userName from location state
  const [paymentMethod, setPaymentMethod] = useState(null); // State to hold payment method

  const handlePayment = async () => {
    // Fetch the booking details to get the payment method
    try {
      const response = await fetch('http://localhost:1000/bookings');
      const data = await response.json();

      // Find the booking details for the specific userName and accommodation
      const bookingDetails = data.find(booking => booking.name === userName );
      
      if (bookingDetails) {
        setPaymentMethod(bookingDetails.paymentMethod);
        
        // Simulate payment processing
        const confirmed = window.confirm(`Are you sure you want to process the payment through ${bookingDetails.paymentMethod}?`);
        if (confirmed) {
          alert(`Processing payment through ${bookingDetails.paymentMethod}...`);
          // Navigate to booking list after payment
          navigate('/');
        }
      } else {
        alert('No booking details found for this accommodation.');
      }
    } catch (error) {
      console.error('Error fetching booking details:', error);
      alert('Error fetching payment method. Please try again.');
    }
  };

  return (
    <Container className="mt-4">
      <h2>Booking Confirmation</h2>
      {accommodation ? (
        <Card>
          <Card.Body>
            <Card.Title>Booking Details</Card.Title>
            <p><strong>Name:</strong> {userName}</p>
            <p><strong>Accommodation:</strong> {accommodation.name}</p>
            <p><strong>Location:</strong> {accommodation.location}</p>
            <p><strong>Score:</strong> {accommodation.score}</p>
            <p><strong>Price:</strong> ₹{accommodation.price}</p>
            <Button variant="primary" onClick={handlePayment}>Book Now</Button> {/* Pay Now button */}
          </Card.Body>
        </Card>
      ) : (
        <p>No booking details available.</p>
      )}
    </Container>
  );
};

export default BookingConfirmation;
